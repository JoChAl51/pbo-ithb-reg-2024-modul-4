package SIA.model.interfaces;

public interface Action {
    String toString();
}
