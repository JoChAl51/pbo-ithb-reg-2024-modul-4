package SIA.model.enumeration;

public enum Status {
    HADIR, ALPHA;
}
