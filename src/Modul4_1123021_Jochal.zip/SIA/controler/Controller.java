package SIA.controler;

public class Controller {
    public String printUserData (String nama) {
        return "";
    }
}
