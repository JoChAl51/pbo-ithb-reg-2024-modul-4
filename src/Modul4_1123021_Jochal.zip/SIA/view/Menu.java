package SIA.view;

import javax.swing.*;

public class Menu {
    public void listMenu() {
        JOptionPane.showInputDialog("Menu:\n1. Menu Satu\n2. Menu Dua\n3. Menu Tiga");
    }
}
